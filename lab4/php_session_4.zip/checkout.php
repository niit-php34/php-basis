<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<form method="post">
		<div>
			<label>Full name</label>
			<input type="text" name="fullname"/>
		</div>

		<div>
			<label>Address</label>
			<textarea></textarea>
		</div>

		<div>
			<input type="submit" value="submit" name="submit"/>
		</div>
	</form>
</body>
</html>